1. Editing Template Parameters

>>> Login to Backend 
>>> Extensions 
>>> Templates 
>>> choose template 
>>> press edit 
>>> on the right top you can change the template parameters

2. CSS Dropdown Menu


>>> Login to Backend 
>>> menues choose menues
>>> choose new
>>> insert all names
>>> go to modules
>>> choose menu module you created 
>>> follow the image inststuctions of the dropdown_menu_parameter.jpg